<?php
    $conn = new mysqli("103.20.200.177", "webpstco_secqldsoftware", "qW+k67GixSw(", "webpstco_secqldsoftware");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
?>